In this folder I have uploaded all notebook which is used to train model,main webapplication file is webapp.py

data size is very big so unable to upload it here beacuse of restriction of size by moodle
#!/usr/bin/env python
# coding: utf-8

# In[3]:


get_ipython().system('pip install opencv-python')


# In[33]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
from torchvision.transforms import ColorJitter, ToPILImage, ToTensor

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Convert OpenCV images to PIL images
pil_images = [ToPILImage()(img) for img in images]

# Apply color jittering
jitter = ColorJitter(brightness=0.5, contrast=0.5, saturation=0.5, hue=0.5)
jittered_images = [jitter(img) for img in pil_images]

# Convert PIL images back to OpenCV format for display
jittered_images_cv2 = [cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR) for img in jittered_images]

# Save jittered images to a destination folder
destination_folder = r"C:\proj_aug"  # <-- Update this path to your desired destination
for idx, img in enumerate(jittered_images_cv2):
    save_path = os.path.join(destination_folder, f"jittered_{image_files[idx]}")
    cv2.imwrite(save_path, img)

# Display 4x4 tile with color jittering
plt.figure(figsize=(4,4))
plt.suptitle("Data With Color Jittering")
for idx, img in enumerate(jittered_images_cv2, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[14]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

def add_noise(img, noise_factor=0.6):
    """
    Add random noise to an image.
    
    Parameters:
    - img: Input image
    - noise_factor: Factor controlling the amount of noise to add
    
    Returns:
    - Noisy image
    """
    # Generate random noise
    noise = np.random.randn(*img.shape) * noise_factor
    
    # Add noise to the image
    noisy_img = img + noise * 255
    noisy_img = np.clip(noisy_img, 0, 255).astype(np.uint8)
    
    return noisy_img

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Apply noise
noisy_images = [add_noise(img) for img in images]

destination_folder = r"C:\proj_aug"  # <-- Update this path to your desired destination
for idx, img in enumerate(noisy_images_cv2):
    save_path = os.path.join(destination_folder, f"jittered_{image_files[idx]}")
    cv2.imwrite(save_path, img)

# Display 4x4 tile with noise
plt.figure(figsize=(4,4))
plt.suptitle("Data With Noise Injection")
for idx, img in enumerate(noisy_images, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[15]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
from PIL import Image

# Load images from folder
folder_path =  r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Convert OpenCV images to PIL images
pil_images = [Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)) for img in images]

# Apply affine transformation
affine_transformed_images = []
for img in pil_images:
    width, height = img.size
    # Define the transformation matrix (this is just an example, you can adjust as needed)
    matrix = [1, 0.5, -100, 0, 1, 0]  # Example coefficients for skewing
    transformed_img = img.transform((width, height), Image.AFFINE, matrix)
    affine_transformed_images.append(transformed_img)

# Convert PIL images back to OpenCV format for display
affine_transformed_images_cv2 = [cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR) for img in affine_transformed_images]

# Display 4x4 tile with affine transformation
plt.figure(figsize=(10, 10))
plt.suptitle("Data With Affine Transformation")
for idx, img in enumerate(affine_transformed_images_cv2, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[28]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Apply Gaussian blur
blurred_images = [cv2.GaussianBlur(img, (19, 19), 0) for img in images]  # (5, 5) is the kernel size

# Display 4x4 tile with Gaussian blur
plt.figure(figsize=(10, 10))
plt.suptitle("Data With Gaussian Blur")
for idx, img in enumerate(blurred_images, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[34]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Convert images to grayscale
grayscale_images = [cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) for img in images]

# Display 4x4 tile with grayscale images
plt.figure(figsize=(4,4))
plt.suptitle("Grayscale Images")
for idx, img in enumerate(grayscale_images, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(img, cmap='gray')
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[30]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

def rotate_image(image, angle):
    """
    Rotate the image by a given angle.
    
    Parameters:
    - image: Input image
    - angle: Rotation angle in degrees
    
    Returns:
    - Rotated image
    """
    # Get the image center
    height, width = image.shape[:2]
    center = (width / 2, height / 2)
    
    # Compute the rotation matrix
    rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1)
    
    # Apply the rotation to the image
    rotated_image = cv2.warpAffine(image, rotation_matrix, (width, height))
    
    return rotated_image

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Apply rotation
rotation_angle = 45  # Rotate by 45 degrees, but you can change this value
rotated_images = [rotate_image(img, rotation_angle) for img in images]

# Display 4x4 tile with rotation
plt.figure(figsize=(10, 10))
plt.suptitle(f"Data Rotated by {rotation_angle} Degrees")
for idx, img in enumerate(rotated_images, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[32]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Apply horizontal flip
flipped_images = [cv2.flip(img, 1) for img in images]  # 1 denotes horizontal flip

# Display 4x4 tile with horizontal flip
plt.figure(figsize=(10, 10))
plt.suptitle("Data With Horizontal Flip")
for idx, img in enumerate(flipped_images, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[35]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

def random_erasing(img, probability=0.5, sl=0.02, sh=0.4, r1=0.3):
    """
    Randomly erases a rectangle in the image.
    
    Parameters:
    - img: Input image
    - probability: Probability of applying the random erasing
    - sl, sh: Minimum and maximum proportion of erased area against input image
    - r1: Minimum aspect ratio of erased area
    
    Returns:
    - Image with a randomly erased rectangle
    """
    if np.random.rand() > probability:
        return img
    
    h, w, _ = img.shape
    area = h * w
    
    target_area = np.random.uniform(sl, sh) * area
    aspect_ratio = np.random.uniform(r1, 1/r1)
    
    h_erase = int(np.sqrt(target_area * aspect_ratio))
    w_erase = int(np.sqrt(target_area / aspect_ratio))
    
    if h_erase > h or w_erase > w:
        return img
    
    x1 = np.random.randint(0, w - w_erase)
    y1 = np.random.randint(0, h - h_erase)
    
    img[y1:y1+h_erase, x1:x1+w_erase, :] = 0  # Set to black. You can set it to any other value if needed.
    
    return img

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Apply random erasing
erased_images = [random_erasing(img) for img in images]

# Display 4x4 tile with erased images
plt.figure(figsize=(4,4))
plt.suptitle("Images with Random Erasing")
for idx, img in enumerate(erased_images, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[44]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

def center_crop(img, desired_size):
    """
    Center crops an image to the desired size.
    
    Parameters:
    - img: Input image
    - desired_size: Tuple (height, width) specifying the desired cropped size
    
    Returns:
    - Center cropped image
    """
    h, w = img.shape[:2]
    new_h, new_w = desired_size

    start_x = (w - new_w) // 2
    start_y = (h - new_h) // 2

    return img[start_y:start_y+new_h, start_x:start_x+new_w]

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Apply center cropping
crop_size = (2000, 2000)  # Example size, adjust as needed
cropped_images = [center_crop(img, crop_size) for img in images]

# Display 4x4 tile with center cropped images
plt.figure(figsize=(4,4))
plt.suptitle("Center Cropped Images")
for idx, img in enumerate(cropped_images, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[45]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

def random_perspective(img, max_warp=0.2):
    """
    Applies a random four-point perspective transformation to an image.
    
    Parameters:
    - img: Input image
    - max_warp: Maximum warp factor for random perspective (default is 0.2)
    
    Returns:
    - Warped image
    """
    h, w = img.shape[:2]
    
    # Define base points
    src_pts = np.array([[0, 0], [w-1, 0], [w-1, h-1], [0, h-1]], dtype=np.float32)
    
    # Generate random warp points
    warp_pts = src_pts + (np.random.rand(4, 2) - 0.5) * max_warp * np.array([w, h])
    warp_pts = warp_pts.astype(np.float32)
    
    # Compute perspective matrix
    matrix = cv2.getPerspectiveTransform(src_pts, warp_pts)
    
    # Apply perspective warp
    warped_img = cv2.warpPerspective(img, matrix, (w, h))
    
    return warped_img

# Load images from folder
folder_path = r"C:\Users\singh\OneDrive\Desktop\project-disseration\tile aug"
image_files = [f for f in os.listdir(folder_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
images = [cv2.imread(os.path.join(folder_path, image_file)) for image_file in image_files]

# Apply random perspective transformation
perspective_images = [random_perspective(img) for img in images]

# Display 4x4 tile with perspective transformed images
plt.figure(figsize=(4,4))
plt.suptitle("Random Perspective Images")
for idx, img in enumerate(perspective_images, 1):
    plt.subplot(4, 4, idx)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.axis('off')

plt.tight_layout()
plt.show()


# In[ ]:




